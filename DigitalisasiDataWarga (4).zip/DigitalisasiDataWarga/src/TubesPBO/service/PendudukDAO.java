/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TubesPBO.service;

import TubesPBO.entity.Alamat;
import TubesPBO.entity.GolonganDawis;
import TubesPBO.entity.Penduduk;
import java.sql.SQLException;
import java.sql.*;

public class PendudukDAO {

    // Menyimpan data Alamat dan mengembalikan ID yang dihasilkan
    private int addAlamat(Alamat alamat, Connection connection) throws SQLException {
        String sql = "INSERT INTO Alamat (blok_rumah) VALUES (?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            preparedStatement.setString(1, alamat.getBlokRumah());
            preparedStatement.executeUpdate();
            ResultSet rs = preparedStatement.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1);
            } else {
                throw new SQLException("Failed to retrieve ID for Alamat");
            }
        }
    }

    // Menyimpan data GolonganDawis dan mengembalikan ID yang dihasilkan
    private int addGolonganDawis(GolonganDawis golonganDawis, Connection connection) throws SQLException {
        String sql = "INSERT INTO GolonganDawis (nama) VALUES (?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            preparedStatement.setString(1, golonganDawis.getNama());
            preparedStatement.executeUpdate();
            ResultSet rs = preparedStatement.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1);
            } else {
                throw new SQLException("Failed to retrieve ID for GolonganDawis");
            }
        }
    }

    // Menyimpan data Penduduk
    public void addPenduduk(Penduduk penduduk) {
        String insertPendudukSQL = "INSERT INTO Penduduk (nik, nama, jeniskelamin, status_tinggal, alamat_id, gol_dawis_id) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection connection = DatabaseUtil.getConnection()) {
            connection.setAutoCommit(false); // Mulai transaksi

            // Insert Alamat
            int alamatId = addAlamat(penduduk.getAlamat(), connection);

            // Insert GolonganDawis
            int golonganDawisId = addGolonganDawis(penduduk.getGolonganDawis(), connection);

            // Insert Penduduk
            try (PreparedStatement preparedStatement = connection.prepareStatement(insertPendudukSQL)) {
                preparedStatement.setString(1, penduduk.getNik());
                preparedStatement.setString(2, penduduk.getNama());
                preparedStatement.setString(3, penduduk.getJeniskelamin());
                preparedStatement.setString(4, penduduk.getStatusTinggal());
                preparedStatement.setInt(5, alamatId);
                preparedStatement.setInt(6, golonganDawisId);
                preparedStatement.executeUpdate();
            }

            connection.commit(); // Commit transaksi

        } catch (SQLException e) {
            e.printStackTrace();
            // Proper logging here
        }
    }

    public Penduduk getPenduduk(String nik) {
        String sql = "SELECT * FROM Penduduk WHERE nik = ?";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, nik);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                Penduduk penduduk = new Penduduk();
                penduduk.setNik(resultSet.getString("nik"));
                penduduk.setNama(resultSet.getString("nama"));
                penduduk.setJeniskelamin(resultSet.getString("jeniskelamin"));
                penduduk.setStatusTinggal(resultSet.getString("status_tinggal"));

                Alamat alamat = new Alamat();
                alamat.setId(resultSet.getInt("alamat_id"));
                penduduk.setAlamat(alamat);

                GolonganDawis golonganDawis = new GolonganDawis();
                golonganDawis.setId(resultSet.getInt("gol_dawis_id"));
                penduduk.setGolonganDawis(golonganDawis);

                return penduduk;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Proper logging here
        }
        return null;
    }

    // Other methods (update, delete, list)
}

