CREATE DATABASE penduduk_db;

USE penduduk_db;

CREATE TABLE Alamat (
    id INT PRIMARY KEY AUTO_INCREMENT,
    blok_rumah VARCHAR(50) NOT NULL
);

CREATE TABLE GolonganDawis (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nama VARCHAR(50) NOT NULL
);

CREATE TABLE Penduduk (
    nik VARCHAR(16) PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    jeniskelamin VARCHAR(10) NOT NULL,
    status_tinggal VARCHAR(50) NOT NULL,
    alamat_id INT,
    gol_dawis_id INT,
    FOREIGN KEY (alamat_id) REFERENCES Alamat(id),
    FOREIGN KEY (gol_dawis_id) REFERENCES GolonganDawis(id)
);

CREATE TABLE Kas (
    id INT PRIMARY KEY AUTO_INCREMENT,
    alamat_id INT,
    jumlah DECIMAL(10, 2),
    tanggal DATE,
    FOREIGN KEY (alamat_id) REFERENCES Alamat(id)
);
