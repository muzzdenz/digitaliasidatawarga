/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TubesPBO.service;

import TubesPBO.entity.Alamat;
import TubesPBO.entity.Kas;
import java.sql.SQLException;

import java.sql.*;
import java.util.List;
import java.util.ArrayList;

public class KasDAO {
    public void addKas(Kas kas) {
        String sql = "INSERT INTO Kas (alamat_id, jumlah, tanggal) VALUES (?, ?, ?)";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, kas.getAlamat().getId());
            preparedStatement.setDouble(2, kas.getJumlah());
            preparedStatement.setDate(3, new Date(kas.getTanggal().getTime()));
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Kas> getKasByAlamat(int alamatId) {
        String sql = "SELECT * FROM Kas WHERE alamat_id = ?";
        List<Kas> kasList = new ArrayList<>();
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, alamatId);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Kas kas = new Kas();
                kas.setId(resultSet.getInt("id"));
                kas.setJumlah(resultSet.getDouble("jumlah"));
                kas.setTanggal(resultSet.getDate("tanggal"));

                Alamat alamat = new Alamat();
                alamat.setId(resultSet.getInt("alamat_id"));
                kas.setAlamat(alamat);

                kasList.add(kas);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return kasList;
    }

    // Metode lainnya
}
