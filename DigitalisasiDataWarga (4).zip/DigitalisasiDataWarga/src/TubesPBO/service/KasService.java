/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TubesPBO.service;

import TubesPBO.entity.Kas;
import java.util.List;

public class KasService {
    private KasDAO kasDAO = new KasDAO();

    public void addKas(Kas kas) {
        kasDAO.addKas(kas);
    }

    public List<Kas> getKasByAlamat(int alamatId) {
        return kasDAO.getKasByAlamat(alamatId);
    }

    public List<Kas> select(int WIDTH, int WIDTH0) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}