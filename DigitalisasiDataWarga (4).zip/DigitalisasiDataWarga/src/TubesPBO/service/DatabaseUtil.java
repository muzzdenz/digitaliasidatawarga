/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TubesPBO.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DatabaseUtil {
    private static final String URL = "jdbc:mysql://localhost:3306/penduduk_db";
    private static final String USER = "root";  // Ganti dengan username Anda
    private static final String PASSWORD = "";  // Ganti dengan password Anda
    private static final Logger LOGGER = Logger.getLogger(DatabaseUtil.class.getName());

    public static Connection getConnection() {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Failed to create the database connection.", e);
            return null;
        }
    }

    public static KasService getKasService() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
