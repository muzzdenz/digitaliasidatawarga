/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TubesPBO.service;

import TubesPBO.entity.Penduduk;
import java.util.List;

public class PendudukService {
    private final PendudukDAO pendudukDAO = new PendudukDAO();

    public void addPenduduk(Penduduk penduduk) {
        pendudukDAO.addPenduduk(penduduk);
    }

    public Penduduk getPenduduk(String nik) {
        return pendudukDAO.getPenduduk(nik);
    }

    // Methods for update, delete, and list

    public List<Penduduk> getAllPenduduk() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}