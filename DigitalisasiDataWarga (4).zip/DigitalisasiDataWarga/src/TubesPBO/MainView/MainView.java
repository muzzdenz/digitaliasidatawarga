/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TubesPBO.MainView;

import TubesPBO.entity.Alamat;
import TubesPBO.entity.GolonganDawis;
import TubesPBO.entity.Kas;
import TubesPBO.entity.Penduduk;
import TubesPBO.service.ExportService;
import TubesPBO.service.KasService;
import TubesPBO.service.PendudukService;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.List;

public class MainView extends JFrame {
    private JTextField nikField, namaField, jeniskelaminField, statusTinggalField, blokRumahField, golDawisField;
    private JTextField kasBlokField, kasJumlahField;
    private PendudukService pendudukService = new PendudukService();
    private KasService kasService = new KasService();

    public MainView() {
        setTitle("Digitalisasi Data Penduduk RT");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        JLabel nikLabel = new JLabel("NIK:");
        nikLabel.setBounds(20, 20, 100, 25);
        add(nikLabel);

        nikField = new JTextField();
        nikField.setBounds(130, 20, 200, 25);
        add(nikField);

        JLabel namaLabel = new JLabel("Nama:");
        namaLabel.setBounds(20, 60, 100, 25);
        add(namaLabel);

        namaField = new JTextField();
        namaField.setBounds(130, 60, 200, 25);
        add(namaField);

        JLabel jeniskelaminLabel = new JLabel("Jenis Kelamin:");
        jeniskelaminLabel.setBounds(20, 100, 100, 25);
        add(jeniskelaminLabel);

        jeniskelaminField = new JTextField();
        jeniskelaminField.setBounds(130, 100, 200, 25);
        add(jeniskelaminField);

        JLabel statusTinggalLabel = new JLabel("Status Tinggal:");
        statusTinggalLabel.setBounds(20, 140, 100, 25);
        add(statusTinggalLabel);

        statusTinggalField = new JTextField();
        statusTinggalField.setBounds(130, 140, 200, 25);
        add(statusTinggalField);

        JLabel blokRumahLabel = new JLabel("Blok Rumah:");
        blokRumahLabel.setBounds(20, 180, 100, 25);
        add(blokRumahLabel);

        blokRumahField = new JTextField();
        blokRumahField.setBounds(130, 180, 200, 25);
        add(blokRumahField);

        JLabel golDawisLabel = new JLabel("Golongan Dawis:");
        golDawisLabel.setBounds(20, 220, 100, 25);
        add(golDawisLabel);

        golDawisField = new JTextField();
        golDawisField.setBounds(130, 220, 200, 25);
        add(golDawisField);

        JButton addPendudukButton = new JButton("Add Penduduk");
        addPendudukButton.setBounds(20, 260, 150, 25);
        addPendudukButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addPenduduk();
            }
        });
        add(addPendudukButton);

        JButton getPendudukButton = new JButton("Get Penduduk");
        getPendudukButton.setBounds(180, 260, 150, 25);
        getPendudukButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                getPenduduk();
            }
        });
        add(getPendudukButton);

        JLabel kasBlokLabel = new JLabel("Blok Rumah Kas:");
        kasBlokLabel.setBounds(20, 300, 100, 25);
        add(kasBlokLabel);

        kasBlokField = new JTextField();
        kasBlokField.setBounds(130, 300, 200, 25);
        add(kasBlokField);

        JLabel kasJumlahLabel = new JLabel("Jumlah Kas:");
        kasJumlahLabel.setBounds(20, 340, 100, 25);
        add(kasJumlahLabel);

        kasJumlahField = new JTextField();
        kasJumlahField.setBounds(130, 340, 200, 25);
        add(kasJumlahField);

        JButton addKasButton = new JButton("Add Kas");
        addKasButton.setBounds(20, 380, 150, 25);
        addKasButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addKas();
            }
        });
        add(addKasButton);

        JButton getKasButton = new JButton("Get Kas");
        getKasButton.setBounds(180, 380, 150, 25);
        getKasButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                getKas();
            }
        });
        add(getKasButton);

        JButton exportKasButton = new JButton("Export Kas to Excel");
        exportKasButton.setBounds(20, 420, 200, 25);
        exportKasButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exportKasToExcel();
            }
        });
        add(exportKasButton);
    }

    private void addPenduduk() {
        Penduduk penduduk = new Penduduk();
        penduduk.setNik(nikField.getText());
        penduduk.setNama(namaField.getText());
        penduduk.setJeniskelamin(jeniskelaminField.getText());
        penduduk.setStatusTinggal(statusTinggalField.getText());

        Alamat alamat = new Alamat();
        alamat.setBlokRumah(blokRumahField.getText());
        penduduk.setAlamat(alamat);

        GolonganDawis golonganDawis = new GolonganDawis();
        golonganDawis.setNama(golDawisField.getText());
        penduduk.setGolonganDawis(golonganDawis);

        pendudukService.addPenduduk(penduduk);
        JOptionPane.showMessageDialog(this, "Penduduk berhasil ditambahkan.");
    }

    private void getPenduduk() {
        String nik = nikField.getText();
        Penduduk penduduk = pendudukService.getPenduduk(nik);
        if (penduduk != null) {
            namaField.setText(penduduk.getNama());
            jeniskelaminField.setText(penduduk.getJeniskelamin());
            statusTinggalField.setText(penduduk.getStatusTinggal());
            blokRumahField.setText(penduduk.getAlamat().getBlokRumah());
            golDawisField.setText(penduduk.getGolonganDawis().getNama());
        } else {
            JOptionPane.showMessageDialog(this, "Penduduk tidak ditemukan.");
        }
    }

    private void addKas() {
        Kas kas = new Kas();
        Alamat alamat = new Alamat();
        alamat.setBlokRumah(kasBlokField.getText());
        kas.setAlamat(alamat);
        kas.setJumlah(Double.parseDouble(kasJumlahField.getText()));
        kas.setTanggal(new Date());

        kasService.addKas(kas);
        JOptionPane.showMessageDialog(this, "Kas berhasil ditambahkan.");
    }

    private void getKas() {
        String blokRumah = kasBlokField.getText();
        Alamat alamat = new Alamat();
        alamat.setBlokRumah(blokRumah);

        List<Kas> kasList = kasService.getKasByAlamat(alamat.getId());
        if (!kasList.isEmpty()) {
            StringBuilder kasInfo = new StringBuilder("Kas untuk blok " + blokRumah + ":\n");
            for (Kas kas : kasList) {
                kasInfo.append("Tanggal: ").append(kas.getTanggal())
                       .append(", Jumlah: ").append(kas.getJumlah()).append("\n");
            }
            JOptionPane.showMessageDialog(this, kasInfo.toString());
        } else {
            JOptionPane.showMessageDialog(this, "Tidak ada kas untuk blok rumah ini.");
        }
    }

    private void exportKasToExcel() {
        String blokRumah = kasBlokField.getText();
        Alamat alamat = new Alamat();
        alamat.setBlokRumah(blokRumah);

        List<Kas> kasList = kasService.getKasByAlamat(alamat.getId());
        if (!kasList.isEmpty()) {
            ExportService exportService = new ExportService();
            exportService.exportKasToExcel(kasList, "kas_" + blokRumah + ".xlsx");
            JOptionPane.showMessageDialog(this, "Kas berhasil diekspor ke Excel.");
        } else {
            JOptionPane.showMessageDialog(this, "Tidak ada kas untuk blok rumah ini.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainView().setVisible(true));
    }
}

