/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TubesPBO.entity;

/**
 *
 * @author tawon
 */
public class Penduduk {

    private String nik;

    private String nama;

    private String jeniskelamin;
 
    private String statusTinggal;

    private Alamat alamat;
 
    private GolonganDawis golonganDawis;

    // Getters and Setters
    public String getNik() { return nik; }
    public void setNik(String nik) { this.nik = nik; }
    public String getNama() { return nama; }
    public void setNama(String nama) { this.nama = nama; }
    public String getJeniskelamin() { return jeniskelamin; }
    public void setJeniskelamin(String jeniskelamin) { this.jeniskelamin = jeniskelamin; }
    public String getStatusTinggal() { return statusTinggal; }
    public void setStatusTinggal(String statusTinggal) { this.statusTinggal = statusTinggal; }
    public Alamat getAlamat() { return alamat; }
    public void setAlamat(Alamat alamat) { this.alamat = alamat; }
    public GolonganDawis getGolonganDawis() { return golonganDawis; }
    public void setGolonganDawis(GolonganDawis golonganDawis) { this.golonganDawis = golonganDawis; }
}