/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TubesPBO.entity;
import com.stripbandunk.jwidget.annotation.TableColumn;
import java.util.Date;

/**
 *
 * @author tawon
 */
public class Kas {
    @TableColumn(number = 1, name = "ID")
    private int id;
    @TableColumn(number = 2, name = "BLOK")
    private Alamat alamat;
    @TableColumn(number = 3, name = "JUMLAH")
    private double jumlah;
    @TableColumn(number = 1, name = "TANGAL")
    private Date tanggal;

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public Alamat getAlamat() { return alamat; }
    public void setAlamat(Alamat alamat) { this.alamat = alamat; }
    public double getJumlah() { return jumlah; }
    public void setJumlah(double jumlah) { this.jumlah = jumlah; }
    public Date getTanggal() { return tanggal; }
    public void setTanggal(Date tanggal) { this.tanggal = tanggal; }
}