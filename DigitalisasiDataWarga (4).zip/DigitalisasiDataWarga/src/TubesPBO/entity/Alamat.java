/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TubesPBO.entity;

/**
 *
 * @author tawon
 */
public class Alamat {
    private int id;
    private String blokRumah;

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getBlokRumah() { return blokRumah; }
    public void setBlokRumah(String blokRumah) { this.blokRumah = blokRumah; }
}